
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Trophy, Medal, Star, TrendingUp } from 'lucide-react';

const mockData = [
  { name: 'Alex J.', points: 450, color: '#4f46e5' },
  { name: 'Sarah S.', points: 420, color: '#6366f1' },
  { name: 'Mike R.', points: 390, color: '#818cf8' },
  { name: 'Emma L.', points: 310, color: '#a5b4fc' },
  { name: 'John D.', points: 280, color: '#c7d2fe' },
];

const Leaderboard: React.FC = () => {
  return (
    <div className="p-4 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-black text-gray-900">Rankings</h2>
        <div className="flex items-center gap-1 bg-indigo-50 px-3 py-1 rounded-full border border-indigo-100">
          <TrendingUp className="w-4 h-4 text-indigo-600" />
          <span className="text-xs font-bold text-indigo-700">Top 1%</span>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-gray-100 p-6 shadow-sm">
        <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-6">Learning Activity</h3>
        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={mockData}>
              <XAxis dataKey="name" hide />
              <Tooltip 
                cursor={{ fill: 'transparent' }}
                contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
              />
              <Bar dataKey="points" radius={[8, 8, 8, 8]} barSize={40}>
                {mockData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-4 flex justify-between items-center px-2">
          <div className="text-center">
            <p className="text-[10px] text-gray-400 font-bold uppercase">Accuracy</p>
            <p className="font-bold text-indigo-600">92%</p>
          </div>
          <div className="text-center">
            <p className="text-[10px] text-gray-400 font-bold uppercase">Streak</p>
            <p className="font-bold text-amber-500">12 Days</p>
          </div>
          <div className="text-center">
            <p className="text-[10px] text-gray-400 font-bold uppercase">Global</p>
            <p className="font-bold text-teal-500">#45</p>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Weekly Leaderboard</h3>
        {mockData.map((user, idx) => (
          <div key={user.name} className={`flex items-center justify-between p-4 bg-white rounded-2xl border shadow-sm ${idx === 0 ? 'border-amber-200 bg-amber-50/30' : 'border-gray-50'}`}>
            <div className="flex items-center gap-4">
              <div className="w-8 flex justify-center">
                {idx === 0 ? <Trophy className="w-6 h-6 text-amber-500" /> : 
                 idx === 1 ? <Medal className="w-6 h-6 text-gray-400" /> :
                 idx === 2 ? <Medal className="w-6 h-6 text-amber-700" /> :
                 <span className="text-sm font-bold text-gray-300">#{idx + 1}</span>}
              </div>
              <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user.name}`} alt="" className="w-10 h-10 rounded-full bg-indigo-50" />
              <div>
                <h4 className="font-bold text-gray-900">{user.name}</h4>
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Level {20 - idx}</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5 font-black text-indigo-600">
              <Star className="w-4 h-4 fill-indigo-600" />
              {user.points}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Leaderboard;

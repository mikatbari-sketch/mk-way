
import React, { useState, useEffect } from 'react';
import { AppView, Question, User, Target, Comment, Notification } from './types';
import { Home, MessageSquarePlus, Trophy, LayoutGrid, User as UserIcon, Bell, Sparkles, Search, MessageCircle, ShieldAlert } from 'lucide-react';
import Feed from './components/Feed';
import AskQuestion from './components/AskQuestion';
import QuizList from './components/Quizzes';
import Leaderboard from './components/Leaderboard';
import Profile from './components/Profile';
import SplashScreen from './components/SplashScreen';
import Notifications from './components/Notifications';
import AuthPortal from './components/AuthPortal';

const STORAGE_KEY = 'mk_way_questions_v2'; 
const REGISTRY_KEY = 'mk_way_registry_v1';
const SESSION_KEY = 'mk_way_session_v1';

const App: React.FC = () => {
  const [showSplash, setShowSplash] = useState(true);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentView, setCurrentView] = useState<AppView>('feed');
  const [isAdmin, setIsAdmin] = useState(false);
  
  const [registry, setRegistry] = useState<User[]>(() => {
    const saved = localStorage.getItem(REGISTRY_KEY);
    return saved ? JSON.parse(saved) : [];
  });

  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem(SESSION_KEY);
    return saved ? JSON.parse(saved) : null;
  });

  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [questions, setQuestions] = useState<Question[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(questions));
  }, [questions]);

  useEffect(() => {
    if (user) {
      localStorage.setItem(SESSION_KEY, JSON.stringify(user));
      setRegistry(prev => prev.map(u => u.id === user.id ? user : u));
      setIsLoggedIn(true);
    } else {
      localStorage.removeItem(SESSION_KEY);
      setIsLoggedIn(false);
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem(REGISTRY_KEY, JSON.stringify(registry));
  }, [registry]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  const handleAuthSuccess = (authUser: User) => {
    if (!registry.find(u => u.id === authUser.id)) {
      setRegistry(prev => [...prev, authUser]);
    }
    setUser(authUser);
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentView('feed');
    setIsAdmin(false);
  };

  const createNotification = (n: Omit<Notification, 'id' | 'timestamp' | 'isRead'>) => {
    const newNotification: Notification = {
      ...n,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now(),
      isRead: false,
    };
    setNotifications(prev => [newNotification, ...prev]);
  };

  const addQuestion = (newQ: Question) => {
    setQuestions(prev => [newQ, ...prev]);
    if (user && newQ.studentId === user.id) {
       setUser(prev => prev ? ({ ...prev, points: prev.points + newQ.points, level: Math.floor((prev.points + newQ.points) / 100) + 1 }) : null);
    }
  };

  const handlePostPublic = (text: string, image?: string) => {
    if (!user) return;
    const newPost: Question = {
      id: Date.now().toString(),
      studentId: user.id,
      studentName: user.name,
      text,
      image,
      target: Target.TEACHER,
      timestamp: Date.now(),
      points: 20,
      tags: ['Community'],
      likes: [],
      comments: [],
      isPrivate: false
    };
    setQuestions(prev => [newPost, ...prev]);
    setUser(prev => prev ? ({ ...prev, points: prev.points + 20, level: Math.floor((prev.points + 20) / 100) + 1 }) : null);
  };

  const adminReply = (questionId: string, answer: string) => {
    setQuestions(prev => prev.map(q => {
      if (q.id === questionId) {
        createNotification({
          userId: q.studentId,
          type: 'answer',
          message: 'A teacher has replied to your message!',
          questionId: q.id,
        });
        return { ...q, answer };
      }
      return q;
    }));
  };

  const toggleLike = (id: string) => {
    if (!user) return;
    setQuestions(prev => prev.map(q => {
      if (q.id === id) {
        const hasLiked = q.likes.includes(user.id);
        return {
          ...q,
          likes: hasLiked ? q.likes.filter(uid => uid !== user.id) : [...q.likes, user.id]
        };
      }
      return q;
    }));
  };

  // Fixed line 154: Added prev.map to find the correct question to update.
  const addComment = (id: string, text: string) => {
    if (!user) return;
    const newComment: Comment = {
      id: Date.now().toString(),
      userId: user.id,
      userName: user.name,
      text,
      timestamp: Date.now()
    };
    setQuestions(prev => prev.map(q => q.id === id ? { ...q, comments: [...q.comments, newComment] } : q));
  };

  const renderView = () => {
    if (!user) return null;

    switch (currentView) {
      case 'feed': return (
        <Feed 
          questions={questions.filter(q => !q.isPrivate)} 
          onRate={() => {}} 
          onLike={toggleLike} 
          onAddComment={addComment} 
          onPostPublic={handlePostPublic}
          currentUserId={user.id} 
          onAskClick={() => setCurrentView('ask')}
          user={user}
        />
      );
      case 'ask': return (
        <AskQuestion 
          user={user} 
          questions={questions.filter(q => q.isPrivate || (isAdmin && q.target === Target.TEACHER))}
          onAsk={addQuestion}
          isAdmin={isAdmin}
          onReply={adminReply}
          onLogoutAdmin={() => {
            setIsAdmin(false);
            setCurrentView('feed');
          }}
        />
      );
      case 'quiz': return <QuizList onPointsEarned={(pts) => setUser(prev => prev ? ({ ...prev, points: prev.points + pts, level: Math.floor((prev.points + pts) / 100) + 1 }) : null)} />;
      case 'leaderboard': return <Leaderboard />;
      case 'profile': return <Profile user={user} onAdminLogin={() => setIsAdmin(true)} isAdmin={isAdmin} onLogout={handleLogout} />;
      case 'notifications': return (
        <Notifications 
          notifications={notifications.filter(n => n.userId === user.id)} 
          onMarkAsRead={(id) => setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n))} 
          onClearAll={() => setNotifications(prev => prev.filter(n => n.userId !== user.id))}
          onNavigateToQuestion={() => setCurrentView('ask')}
        />
      );
      default: return <Feed questions={questions.filter(q => !q.isPrivate)} currentUserId={user.id} onAskClick={() => setCurrentView('ask')} user={user} onRate={() => {}} onLike={toggleLike} onAddComment={addComment} onPostPublic={handlePostPublic} />;
    }
  };

  if (showSplash) {
    return <SplashScreen />;
  }

  if (!isLoggedIn) {
    return <AuthPortal onAuthSuccess={handleAuthSuccess} existingUsers={registry} />;
  }

  return (
    <div className="flex flex-col h-screen max-w-md mx-auto bg-[#f3f0ff] shadow-2xl overflow-hidden relative border-x border-slate-200">
      <header className="px-5 py-4 flex items-center justify-between bg-white/60 backdrop-blur-md border-b border-white/20 sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-black rounded-full flex items-center justify-center shadow-md">
            <span className="text-white font-black italic text-sm">MK</span>
          </div>
          <div>
            <h1 className="font-extrabold text-xl leading-none text-[#0f172a]">MK-way</h1>
            <p className="text-[10px] font-bold text-orange-500 uppercase tracking-[0.2em] mt-0.5">Discovery Lab</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <button className="p-2.5 rounded-full bg-white/40 text-[#94a3b8] relative border border-white/20 shadow-sm">
            <MessageCircle size={20} />
          </button>
          <button 
            onClick={() => setCurrentView('notifications')}
            className={`p-2.5 rounded-full bg-white/40 text-[#94a3b8] relative border border-white/20 shadow-sm transition-all ${
              currentView === 'notifications' ? 'bg-orange-500 text-white border-transparent' : ''
            }`}
          >
            <Bell size={20} />
            {notifications.filter(n => !n.isRead && n.userId === user?.id).length > 0 && (
              <span className="absolute top-0 right-0 w-4 h-4 bg-red-500 border-2 border-white rounded-full text-[8px] font-black text-white flex items-center justify-center">
                {notifications.filter(n => !n.isRead && n.userId === user?.id).length}
              </span>
            )}
          </button>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto bg-transparent">
        {renderView()}
      </main>

      <div className="bg-white/60 backdrop-blur-md px-6 pt-2 pb-6 safe-bottom border-t border-white/20">
        <nav className="flex justify-between items-center relative">
          <NavButton active={currentView === 'feed'} icon={<Home />} onClick={() => setCurrentView('feed')} />
          <NavButton active={currentView === 'quiz'} icon={<LayoutGrid />} onClick={() => setCurrentView('quiz')} />
          
          <div className="relative -top-6">
            <button 
              onClick={() => setCurrentView('ask')}
              className="w-16 h-16 rounded-full flex items-center justify-center shadow-[0_12px_24px_-8px_rgba(249,115,22,0.4)] transition-all active:scale-90 border-4 border-white bg-orange-500 text-white"
            >
              <div className="relative">
                 <MessageSquarePlus className="w-8 h-8" />
                 <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-orange-200 rounded-full"></div>
              </div>
            </button>
          </div>

          <NavButton active={currentView === 'leaderboard'} icon={<Trophy />} onClick={() => setCurrentView('leaderboard')} />
          <NavButton active={currentView === 'profile'} icon={<UserIcon />} onClick={() => setCurrentView('profile')} />
        </nav>
      </div>
    </div>
  );
};

const NavButton: React.FC<{ active: boolean; icon: React.ReactNode; onClick: () => void }> = ({ active, icon, onClick }) => (
  <button 
    onClick={onClick} 
    className={`p-3 transition-all ${
      active ? 'text-orange-500' : 'text-[#94a3b8]'
    }`}
  >
    {React.cloneElement(icon as React.ReactElement, { size: 28, strokeWidth: active ? 2.5 : 2 })}
  </button>
);

export default App;
